using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class combatControler : MonoBehaviour
{
    public int EnemyN = 2, PlayersN = 1;
    public int EnemySelect, PlayersSelect;
    public GameObject enemies, players;
    bool turn = true;


    private void Start()
    {
        character stats = players.transform.GetChild(PlayersSelect).GetComponent<character>();
        stats.Select(true);
    }

    private void Update()
    {
        if (EnemyN >= 0)
        {
            enemies.transform.GetChild(EnemySelect).GetComponent<character>().Select(false);
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                Debug.Log("hola");
                EnemySelect--;
            }
            if (Input.GetKeyDown(KeyCode.DownArrow))
            { 
                EnemySelect++; 
            }
            EnemySelect = Mathf.Clamp(EnemySelect, 0, EnemyN);
            enemies.transform.GetChild(EnemySelect).GetComponent<character>().Select(true);
        }
    }

    public void Atack()
    {
        if (turn && PlayersN >= 0) 
        { 
            character ch = players.transform.GetChild(PlayersSelect).GetComponent<character>();
            ch.Atack();

            if (PlayersSelect == PlayersN)
            {
                PlayersSelect = 0;
                turn = false;
                StartCoroutine(AtackE());
            }
            else PlayersSelect++;

            ch.Select(false);
            ch = players.transform.GetChild(PlayersSelect).GetComponent<character>();
            ch.Select(true);
        }
    }


    IEnumerator AtackE()
    {
        yield return new WaitForSecondsRealtime(1f);
        for (int i = 0; i <= EnemyN; i++)
        {
            enemies.transform.GetChild(i).GetComponent<character>().Atack();
            yield return new WaitForSecondsRealtime(1f);
        }
        turn = true;
    }
}
